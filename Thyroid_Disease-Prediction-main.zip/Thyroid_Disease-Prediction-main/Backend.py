from flask import Flask, request, jsonify, render_template
import pandas as pd
import pickle
import os

app = Flask(__name__)

# Load model files
model = pickle.load(open("best_model.pkl", "rb"))
preprocessor = pickle.load(open("preprocessor.pkl", "rb"))
le = pickle.load(open("label_encoder.pkl", "rb"))


@app.route("/")
def home():
    return render_template("index.html")

@app.route("/contact")
def contact():
    return render_template("contact.html")


@app.route("/predict", methods=["POST"])
def predict():
    try:
        data = request.form

        input_data = pd.DataFrame({
            'age': [float(data['age'])],
            'sex': [float(data['sex'])],
            'on thyroxine': [float(data['on_thyroxine'])],
            'query on thyroxine': [float(data['query_on_thyroxine'])],
            'on antithyroid medication': [float(data['on_antithyroid_medication'])],
            'sick': [float(data['sick'])],
            'pregnant': [float(data['pregnant'])],
            'thyroid surgery': [float(data['thyroid_surgery'])],
            'I131 treatment': [float(data['i131_treatment'])],
            'query hypothyroid': [float(data['query_hypothyroid'])],
            'query hyperthyroid': [float(data['query_hyperthyroid'])],
            'lithium': [float(data['lithium'])],
            'goitre': [float(data['goitre'])],
            'tumor': [float(data['tumor'])],
            'hypopituitary': [float(data['hypopituitary'])],
            'psych': [float(data['psych'])],
            'TSH measured': [float(data['tsh_measured'])],
            'TSH': [float(data['tsh'])],
            'T3 measured': [float(data['t3_measured'])],
            'TT4 measured': [float(data['tt4_measured'])],
            'TT4': [float(data['tt4'])],
            'T4U measured': [float(data['t4u_measured'])],
            'T4U': [float(data['t4u'])],
            'FTI measured': [float(data['fti_measured'])],
            'FTI': [float(data['fti'])]
        })

        # preprocessing
        input_processed = preprocessor.transform(input_data)

        # prediction
        pred = model.predict(input_processed)[0]
       # Manual mapping
        if pred == 0:
           result = "Thyroid Negative"
        else:
           result = "Thyroid Positive"

        return jsonify({"prediction": result})

    except Exception as e:
        return jsonify({"prediction": "Error: " + str(e)})


if __name__ == "__main__":
    app.run(debug=True)